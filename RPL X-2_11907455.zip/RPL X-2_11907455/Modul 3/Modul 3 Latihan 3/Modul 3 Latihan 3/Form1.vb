﻿Public Class Form1
    'Untuk menghitung jumlah data pada listbox 2
    Sub hitung()
        Label3.Text = ListBox2.Items.Count & " Item "
    End Sub
    'Untuk Menambahkan Makanan pada listbox
    Sub tambah()
        With ListBox1.Items
            .Add("Nasi Goreng Cinta")
            .Add("Bebek Rebus Jahe")
            .Add("Cumi-cumi Casablanca")
            .Add("Krecek Tahu")
        End With
        hitung()
    End Sub
    'Memanggil fungsi tambah saat form di play
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call tambah()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ListBox1.SelectedItem = "" Then
            MsgBox("pilih makanan yang ingin anda pesan")
        Else
            ListBox2.Items.Add(ListBox1.SelectedItem)
            ListBox1.Items.Remove(ListBox1.SelectedItem)
        End If
        hitung()
    End Sub
    'Membatalkan pesanan dari listbox2
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ListBox2.SelectedItem = "" Then
            MsgBox("Pilih makanan yang ingin anda hapus")
        Else
            ListBox1.Items.Add(ListBox2.SelectedItem)
            ListBox2.Items.Remove(ListBox2.SelectedItem)
        End If
    End Sub
    'Menghapus seluruh pesanan
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        ListBox2.Items.Clear()
        ListBox1.Items.Clear()
        tambah()
        hitung()
    End Sub

End Class
