﻿Public Class Form1
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click, Label9.Click, Label8.Click, Label7.Click, Label6.Click, Label5.Click, Label4.Click, Label14.Click, Label13.Click, Label12.Click, Label11.Click, Label10.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox15.Text = Val(TextBox3.Text) + Val(TextBox4.Text) + Val(TextBox5.Text) + Val(TextBox6.Text)
        TextBox2.Text = Val(TextBox1.Text) - (Val(TextBox15.Text) + Val(TextBox16.Text) + Val(TextBox17.Text))
        If TextBox15.Text <> 0 Then
            Panel1.BackColor = Color.Green
        Else
            Panel1.BackColor = Color.Red
        End If
    End Sub
    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox16.Text = Val(TextBox7.Text) + Val(TextBox8.Text) + Val(TextBox9.Text) + Val(TextBox10.Text)
        TextBox2.Text = Val(TextBox1.Text) - (Val(TextBox15.Text) + Val(TextBox16.Text) + Val(TextBox17.Text))
        If TextBox16.Text <> 0 Then
            Panel2.BackColor = Color.Green
        Else
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox17.Text = Val(TextBox11.Text) + Val(TextBox14.Text) + Val(TextBox12.Text) + Val(TextBox13.Text)
        TextBox2.Text = Val(TextBox1.Text) - (Val(TextBox15.Text) + Val(TextBox16.Text) + Val(TextBox17.Text))
        If TextBox17.Text <> 0 Then
            Panel3.BackColor = Color.Green
        Else
            Panel3.BackColor = Color.Red
        End If
    End Sub
End Class
